import GameEvent from "../../../Wolfie2D/Events/GameEvent";
import { GameEventType } from "../../../Wolfie2D/Events/GameEventType";
import { PlayerTweens,PlayerAnimations } from "../PlayerController";
import PlayerState from "./PlayerState";
import Level1 from "../../Scenes/HW3Level1";

/**
 * The Dead state for the player's FSM AI. 
 */
export default class Dead extends PlayerState {

    // public static readonly DYING_MUSIC_PATH = "hw4_assets/sound/dying.wav";

    // Trigger the player's death animation when we enter the dead state
    public onEnter(options: Record<string, any>): void {
        this.owner.animation.stop();
        this.owner.animation.playIfNotAlready(PlayerAnimations.DYING);
        this.emitter.fireEvent(GameEventType.PLAY_SOUND, {key: Level1.DYING_KEY, loop: false, holdReference: true});
        this.owner.tweens.play(PlayerTweens.DEATH);
    }

    // Ignore all events from the rest of the game
    public handleInput(event: GameEvent): void { }

    // Empty update method - if the player is dead, don't update anything
    public update(deltaT: number): void {}

    public onExit(): Record<string, any> { return {}; }
    
}